#include<iostream>
#include<string>
using namespace std;


int main() {

	//here is the list of characteristic
	string Name;
	string Species;
	string Spe_ab; //Special ability
	int Age;
	int Health;
	int Magic;
	int Strength;
	int Speed;
	int Intelligence;

	//This is my awesome app
	cout << "Superb RPG chracter creator" << endl 
		<< "Welcome! We are about to create your own chracter. "<< endl 
		<< "Please type one word for each question below" << endl 
		<< endl << endl << "What is the name of your chracter" << endl;

	cin >> Name;

	cout << endl << "What is " << Name << " 's species? " << endl;

	cin >> Species;

	cout << endl << "What special ability does " << Name << " have? " << endl
		<<"ONE single word ONLY!!!" << endl;

	cin >> Spe_ab;

	cout << endl << "How old is " << Name << "?" << endl;

	cin >> Age;

	cout << endl << "Default health for " << Name << "... " << endl;

	cin >> Health;

	cout << endl << "Default magic for " << Name << "... " << endl;

	cin >> Magic;

	cout << endl << "Default strength for " << Name << "... " << endl;

	cin >> Strength;

	cout << endl << "Default speed for " << Name << "... " << endl;

	cin >> Speed;

	cout << endl << "Default intelligence for " << Name << "... " << endl;

	cin >> Intelligence;

	cout << endl << endl << "Name: " << Name << endl
		<< "Species: " << Species << endl 
		<< "Special Ability: " << Spe_ab << endl 
		<< "Age: " << Age << endl 
		<< "Health: " << Health << endl 
		<< "Magic: " << Magic << endl 
		<< "Strength: " << Strength << endl 
		<< "Speed: " << Speed << endl 
		<< "Intelligence: " << Intelligence << endl;


	system("pause");
	return 0;

}